package dev.dwmod;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public class UnitBlockItem extends BlockItem {
    private final String id;
    private final String faction;
    private final String unitClass;
    private final int color;
    private final boolean signature;

    public UnitBlockItem(Block block, Properties properties, String id, String faction, int color, String unitClass, boolean signature) {
        super(block, properties);
        this.id = id;
        this.faction = faction;
        this.color = color;
        this.unitClass = unitClass;
        this.signature = signature;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("faction." + DystopianWarsMod.MODID + "." + faction)
                .withStyle(Style.EMPTY.withColor(color)));
        if (unitClass != null && !unitClass.isEmpty()) {
            tooltip.add(Component.translatable("class." + DystopianWarsMod.MODID + "." + unitClass)
                    .withStyle(ChatFormatting.GRAY));
        }
        String infoKey = "unitinfo." + DystopianWarsMod.MODID + "." + id;
        if (Language.getInstance().has(infoKey)) {
            tooltip.add(Component.translatable(infoKey).withStyle(ChatFormatting.YELLOW));
        } else if (signature) {
            tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".stats")
                    .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
        }
        tooltip.add(Component.translatable("tooltip." + DystopianWarsMod.MODID + ".place")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
