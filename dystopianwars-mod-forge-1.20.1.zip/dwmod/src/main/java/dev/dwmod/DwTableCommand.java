package dev.dwmod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** /dwtable [width depth] - builds a flat "sea" play area (default 48 x 36 blocks = 48" x 36") under your feet. */
@Mod.EventBusSubscriber(modid = DystopianWarsMod.MODID)
public final class DwTableCommand {
    private DwTableCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("dwtable")
                .requires(src -> src.hasPermission(2))
                .executes(ctx -> build(ctx.getSource(), 48, 36))
                .then(Commands.argument("width", IntegerArgumentType.integer(8, 144))
                        .then(Commands.argument("depth", IntegerArgumentType.integer(8, 144))
                                .executes(ctx -> build(ctx.getSource(),
                                        IntegerArgumentType.getInteger(ctx, "width"),
                                        IntegerArgumentType.getInteger(ctx, "depth"))))));
    }

    private static int build(CommandSourceStack src, int width, int depth) {
        ServerLevel level = src.getLevel();
        Vec3 v = src.getPosition();
        BlockPos origin = BlockPos.containing(v.x, v.y, v.z);
        int floorY = origin.getY() - 1;
        BlockState sea = Blocks.BLUE_CONCRETE.defaultBlockState();
        BlockState grid = Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState();
        BlockState edge = Blocks.WHITE_CONCRETE.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = 0; dx < width; dx++) {
            for (int dz = 0; dz < depth; dz++) {
                BlockState state = sea;
                if (dx == 0 || dz == 0 || dx == width - 1 || dz == depth - 1) {
                    state = edge;
                } else if (dx % 10 == 0 || dz % 10 == 0) {
                    state = grid;
                }
                BlockPos p = new BlockPos(origin.getX() + dx, floorY, origin.getZ() + dz);
                level.setBlock(p, state, 2);
                level.setBlock(p.above(), air, 2);
                level.setBlock(p.above(2), air, 2);
            }
        }
        int small = Math.min(width, depth);
        island(level, origin.getX() + width / 2, origin.getZ() + depth / 2, floorY, Math.max(2, small / 9));
        island(level, origin.getX() + width / 4, origin.getZ() + depth / 2, floorY, Math.max(2, small / 12));
        island(level, origin.getX() + (3 * width) / 4, origin.getZ() + depth / 2, floorY, Math.max(2, small / 12));
        src.sendSuccess(() -> Component.translatable("msg." + DystopianWarsMod.MODID + ".table.done", width, depth), true);
        return 1;
    }

    /** A small symmetric island (terrain feature): sand with a grass top, one or two blocks high. */
    private static void island(ServerLevel level, int cx, int cz, int floorY, int radius) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radius) {
                    continue;
                }
                int height = dist <= radius * 0.5D ? 2 : 1;
                for (int h = 1; h <= height; h++) {
                    BlockState state = h == height
                            ? (dist <= radius - 1.5D ? Blocks.GRASS_BLOCK.defaultBlockState() : Blocks.SAND.defaultBlockState())
                            : Blocks.SAND.defaultBlockState();
                    level.setBlock(new BlockPos(cx + dx, floorY + h, cz + dz), state, 2);
                }
            }
        }
    }
}
