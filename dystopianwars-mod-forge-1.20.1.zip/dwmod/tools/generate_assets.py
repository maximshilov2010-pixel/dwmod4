#!/usr/bin/env python3
"""Generates all data-driven files of the mod: UnitData.java, blockstates, models,
loot tables, textures and lang files. Run from the project root:  python3 tools/generate_assets.py
Requires Pillow (pip install pillow)."""
import data_crown, data_imperium, books
import json, os, sys
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import models3d

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODID = "dystopianwars"
RES = os.path.join(ROOT, "src/main/resources")
ASSETS = os.path.join(RES, "assets", MODID)
DATA = os.path.join(RES, "data", MODID)
JAVA = os.path.join(ROOT, "src/main/java/dev/dwmod/UnitData.java")

# id, color, name_en, name_ru
FACTIONS = [
    ("crown", 0xB3262E, "Crown", "Корона"),
    ("union", 0x2C5AA0, "Union", "Союз"),
    ("imperium", 0x7A7F8C, "Imperium", "Империум"),
    ("commonwealth", 0x3F8F4A, "Commonwealth", "Содружество"),
    ("empire", 0xD9A21B, "Empire", "Империя"),
    ("alliance", 0x5FA8D3, "Alliance", "Альянс"),
    ("sultanate", 0xD9712B, "Sultanate", "Султанат"),
    ("enlightened", 0x1FB5A5, "Enlightened", "Просвещённые"),
]

# class key: (en, ru) -- generic role descriptions only, no invented statistics
CLASSES = {
    "frigate": ("Frigate", "Фрегат — лёгкий корабль-экран"),
    "destroyer": ("Destroyer", "Эсминец — быстрый корабль, опасный не по размеру"),
    "cruiser": ("Cruiser", "Крейсер — основа боевой линии"),
    "monitor": ("Monitor", "Монитор — приземистый артиллерийский корабль"),
    "battleship": ("Battleship", "Линкор — тяжёлый корабль линии"),
    "carrier": ("Carrier", "Авианосец — запускает эскадрильи SRS"),
    "colossus": ("Colossus", "Колосс — гигантская боевая машина"),
    "airship": ("Airship", "Воздушный корабль"),
    "skyfortress": ("Skyfortress", "Небесная крепость / воздушный флагман"),
    "submarine": ("Submarine", "Подводный корабль"),
    "srs": ("Short Range Squadron", "Эскадрилья ближнего действия (SRS)"),
    "escort": ("Escort", "Жетон эскорта"),
    "stronghold": ("Mobile Stronghold", "Мобильная крепость"),
    "transport": ("Transport", "Транспорт / конвейер / торговое судно"),
    "automata": ("Automata", "Автомат / боевой механизм"),
}
GENERIC = ["frigate", "destroyer", "cruiser", "battleship", "carrier",
           "colossus", "airship", "submarine", "srs", "escort"]

# Signature units: names are taken from official Warcradle material (see README).
SIGNATURE = {
    "crown": [("sabre", "Sabre Command Cruiser", "cruiser"), ("albion", "Albion Cruiser", "cruiser"),
              ("lancelot", "Lancelot Heavy Cruiser", "cruiser"), ("picton", "Picton Light Cruiser", "cruiser"),
              ("igraine", "Igraine Cruiser", "cruiser"), ("newfoundland", "Newfoundland Attack Cruiser", "cruiser"),
              ("bedivere", "Bedivere Monitor", "monitor"), ("hotspur", "Hotspur Carrier", "carrier"),
              ("caliburn", "Caliburn Frigate", "frigate"), ("excalibur", "Excalibur Heavy Destroyer", "destroyer")],
    "union": [("enterprise", "Enterprise Heavy Carrier", "carrier"), ("defiant", "Defiant Destroyer", "destroyer"),
              ("excelsior", "Excelsior Heavy Aircruiser", "airship"), ("steward", "Steward Sentry Airship", "airship"),
              ("bogota", "Bogota Carryall", "airship"), ("corsair", "Corsair Fighters", "srs")],
    "imperium": [("stark", "Stark Skyfortress", "skyfortress"), ("hochmeister", "Hochmeister Vitruvian Colossus", "colossus"),
                 ("metzger", "Metzger Vitruvian Colossus", "colossus")],
    "commonwealth": [("marena", "Marena Vitruvian Colossus", "colossus"), ("murmansk", "Murmansk Mobile Stronghold", "stronghold"),
                     ("kometa", "Kometa Interceptors", "srs"), ("szpada", "Szpada Swordwings", "srs")],
    "empire": [("hokkaido", "Hokkaido Heavy Cruiser", "cruiser"), ("honshu", "Honshu Light Cruiser", "cruiser"),
               ("osaka", "Osaka Cruiser", "cruiser"), ("yamaguchi", "Yamaguchi Advanced Cruiser", "cruiser"),
               ("oni", "Oni Command Cruiser", "cruiser"), ("kanagawa", "Kanagawa Heavy Monitor", "monitor"),
               ("miyagi", "Miyagi Advanced Monitor", "monitor"), ("kyoto", "Kyoto Fast Frigate", "frigate"),
               ("sakata", "Sakata Heavy Destroyer", "destroyer"), ("heilong", "Heilong Battleship", "battleship"),
               ("shenlong", "Shenlong Draconic Colossus", "colossus"), ("sanshin", "Sanshin Judgement Aircruiser", "airship"),
               ("bangpae", "Bangpae Automata", "automata"), ("doksuri", "Doksuri Fighters", "srs"),
               ("rinexo", "Rin-Exo Submersibles", "srs")],
    "alliance": [("ecuyere", "Ecuyere Frigate", "frigate"), ("bretteur", "Bretteur Destroyer", "destroyer"),
                 ("chevalier", "Chevalier Cruiser", "cruiser"), ("charlemagne", "Charlemagne Heavy Cruiser", "cruiser"),
                 ("concordat", "Concordat Command Cruiser", "cruiser"), ("loire", "Loire Light Cruiser", "cruiser"),
                 ("picardy", "Picardy Monitor", "monitor"), ("vauban", "Vauban Sky Fortress", "skyfortress")],
    "sultanate": [("lyceum", "Lyceum Aerial Dreadnought", "skyfortress"), ("nasr", "Nasr Skyship", "airship"),
                  ("hirka", "Hirka Skycutter", "airship"), ("alsaqr", "Alsaqr Skybarque", "airship"),
                  ("titan", "Titan Heavy Conveyer", "airship")],
    "enlightened": [("scythe", "Scythe Drones and Fighters", "srs"), ("icarus", "Icarus Aeronautic Fabricator", "airship"),
                    ("ketos", "Ketos Myriapoda Colossus Automata", "automata")],
}

# marker id, color, glyph key, en, ru
MARKERS = [
    ("marker_damage", 0xC62828, "x", "Damage Marker", "Жетон урона"),
    ("marker_disorder", 0xF2C21B, "bang", "Disorder Marker", "Жетон Disorder"),
    ("marker_activated", 0x8A8F98, "dot", "Activated Marker", "Жетон «активирован»"),
    ("marker_objective", 0xE0A800, "star", "Objective Marker", "Жетон цели"),
    ("marker_crippled", 0x2B2B2B, "skull", "Crippled Marker", "Жетон Crippled"),
    ("marker_minefield", 0x4E8F3A, "mine", "Minefield Marker", "Жетон минного поля"),
]

GLYPHS = {
    "frigate": ["##", "####", "####", "####", "####", "####", "####", "##", "#..#"],
    "destroyer": ["##", "##", "####", "#oo#", "####", "####", "#oo#", "####", "##", "##"],
    "cruiser": ["##", "####", "#oo#", "######", "######", "#oooo#", "######", "######", "####", "#..#"],
    "monitor": ["####", "######", "######", "##oo##", "##oo##", "######", "######", "####"],
    "battleship": ["##", "####", "#oo#", "######", "#o##o#", "######", "#oooo#", "######", "#o##o#", "######", "####"],
    "carrier": ["#####", "#####", "#o.o#", "#####", "#o.o#", "#####", "#o.o#", "#####", "#####"],
    "colossus": ["..##..", "..##..", "######", "######", "#.##.#", "#.##.#", "..##..", "..##..", ".#..#.", ".#..#.", "##..##"],
    "airship": [".####.", "######", "#oooo#", "######", "######", ".####.", "..##..", "..##.."],
    "skyfortress": [".######.", "########", "#oo##oo#", "########", "########", "#o####o#", "########", ".######."],
    "submarine": ["..##..", ".####.", ".#oo#.", ".####.", ".####.", ".####.", ".####.", "..##..", "..##.."],
    "stronghold": ["#.#.#.#", "#######", "#oo.oo#", "#######", "#######", "#######", "#.###.#"],
    "automata": ["####", "#oo#", "####", "######", "#.##.#", "#.##.#", "##..##"],
}
FULL = {
    "srs": ["............", ".....#......", "....###.....", ".....#......", "..#......#..", ".###....###.",
            "..#......#..", "............", ".....#......", "....###.....", ".....#......", "............"],
    "escort": ["............", "............", "..##....##..", "..##....##..", "............", "....####....",
               "....####....", "............", "..##....##..", "..##....##..", "............", "............"],
    "x": ["............", "..##....##..", "...##..##...", "....####....", ".....##.....", "....####....",
          "...##..##...", "..##....##..", "............", "............", "............", "............"],
    "bang": ["............", ".....##.....", ".....##.....", ".....##.....", ".....##.....", ".....##.....",
             ".....##.....", "............", ".....##.....", ".....##.....", "............", "............"],
    "dot": ["............", "............", "....####....", "...######...", "...######...", "...######...",
            "...######...", "....####....", "............", "............", "............", "............"],
    "star": ["............", ".....##.....", ".....##.....", "..########..", "...######...", "....####....",
             "...##..##...", "..##....##..", "............", "............", "............", "............"],
    "skull": ["............", "...######...", "..########..", "..#o####o#..", "..#o####o#..", "..########..",
              "...######...", "....#..#....", "....####....", "............", "............", "............"],
    "mine": ["............", ".....##.....", "..#..##..#..", "...######...", "..########..", "###########.",
             "..########..", "...######...", "..#..##..#..", ".....##.....", "............", "............"],
}

LIGHT = (240, 232, 210)


def rgb(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def glyph_rows(key):
    if key in FULL:
        return [r.ljust(12, ".")[:12] for r in FULL[key]]
    core = GLYPHS[key]
    rows = [r.center(12, ".") for r in core]
    top = (12 - len(rows)) // 2
    return ["." * 12] * top + rows + ["." * 12] * (12 - len(rows) - top)


def make_token_texture(color, glyph_key, signature):
    col = rgb(color)
    img = Image.new("RGBA", (16, 16), shade(col, 0.33) + (255,))
    px = img.load()
    for i in range(16):
        for p in ((i, 0), (i, 15), (0, i), (15, i)):
            px[p] = col + (255,)
    for y, row in enumerate(glyph_rows(glyph_key)):
        for x, ch in enumerate(row):
            if ch == "#":
                px[x + 2, y + 2] = LIGHT + (255,)
            elif ch == "o":
                px[x + 2, y + 2] = shade(col, 0.85) + (255,)
    if signature:
        for dx in range(2):
            for dy in range(2):
                px[13 + dx - 1, 1 + dy] = (255, 215, 0, 255)
    return img


def make_side_texture(color):
    col = rgb(color)
    img = Image.new("RGBA", (16, 16), col + (255,))
    px = img.load()
    for i in range(16):
        for p in ((i, 0), (i, 15), (0, i), (15, i)):
            px[p] = shade(col, 0.6) + (255,)
    return img


def make_tool_textures():
    out = {}
    # action dice: white die with pips
    d = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); p = d.load()
    for x in range(2, 14):
        for y in range(2, 14):
            p[x, y] = (245, 245, 245, 255)
    for i in range(2, 14):
        for q in ((i, 2), (i, 13), (2, i), (13, i)):
            p[q] = (60, 60, 60, 255)
    for (x, y) in [(5, 5), (10, 5), (5, 10), (10, 10), (7, 7), (8, 8)]:
        for dx in range(2):
            for dy in range(2):
                p[x + dx - 1 + 1, y + dy - 1 + 1] = (30, 30, 30, 255)
    out["action_dice"] = d
    # critical die: red die
    c = d.copy(); q = c.load()
    for x in range(3, 13):
        for y in range(3, 13):
            q[x, y] = (200, 40, 40, 255)
    for (x, y) in [(5, 5), (10, 5), (7, 8), (5, 10), (10, 10)]:
        q[x, y] = (255, 230, 230, 255); q[x + 1, y] = (255, 230, 230, 255)
    out["critical_die"] = c
    # ruler
    r = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); s = r.load()
    for i in range(1, 15):
        for t in range(5, 11):
            s[i, t] = (200, 160, 90, 255) if (14 - i) >= 0 else s[i, t]
        for t in (5, 10):
            s[i, t] = (110, 80, 40, 255)
        if i % 2 == 1:
            s[i, 6] = (60, 40, 20, 255)
            if i % 4 == 1:
                s[i, 7] = (60, 40, 20, 255)
    out["ruler"] = r
    return out


def make_palette(color):
    col = rgb(color)
    slots = [col, shade(col, 0.45), (225, 214, 190), (120, 126, 138), (28, 28, 32), (240, 190, 40),
             (240, 240, 240), tuple(int(c + (255 - c) * 0.45) for c in col)]
    img = Image.new("RGBA", (16, 16))
    px = img.load()
    for i, c in enumerate(slots):
        cx, cy = (i % 4) * 4, (i // 4) * 4
        for x in range(4):
            for y in range(4):
                px[cx + x, cy + y] = c + (255,)
    return img


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def save_json(path, obj):
    write(path, json.dumps(obj, ensure_ascii=False, indent=2) + "\n")


INFO = {}  # unit id -> (en, ru) tooltip line
BOOKS = {}


def build_units():
    units = []  # id, faction, class, name, signature
    seen = set()

    def add(fid, name, cls, info=None):
        uid = f"{fid}_{books.slug(name)}"
        assert uid not in seen, uid
        seen.add(uid)
        units.append((uid, fid, cls, name, True))
        if info:
            INFO[uid] = info
    for fid, _c, fen, _fru in FACTIONS:
        if fid == "crown":
            for u in data_crown.UNITS:
                st = u["stats"]
                line = f"{u['cat']} | {u['pts']} pts | " if u["pts"] else f"{u['cat']} | "
                line += f"DEF {st['DEF']} ARM {st['ARM']} HUL {st['HUL']}"
                add(fid, u["name"], u["cls"], (line, line))
            add(fid, "Defiance Fighters", "srs", ("SRS token", "Жетон SRS"))
        elif fid == "imperium":
            for u in data_imperium.UNITS:
                st = u["stats"]
                line = f"{u['cat']} | {u['pts']} pts | DEF {st['DEF']} ARM {st['ARM']} HUL {st['HUL']}"
                add(fid, u["name"], u["cls"], (line, line))
            for n, k in data_imperium.SRS:
                add(fid, n, k, ("SRS / token", "Жетон SRS / эскорт"))
        else:
            for uid, name, cls in SIGNATURE[fid]:
                units.append((f"{fid}_{uid}", fid, cls, name, True))
            for cls in GENERIC:
                units.append((f"{fid}_generic_{cls}", fid, cls, None, False))
    return units


def main():
    global BOOKS
    BOOKS = books.write_books(os.path.join(ASSETS, "guides", "ru"))
    units = build_units()
    fcolor = {f[0]: f[1] for f in FACTIONS}
    fen = {f[0]: f[2] for f in FACTIONS}
    fru = {f[0]: f[3] for f in FACTIONS}
    lang_en, lang_ru = {}, {}

    # ---- textures + block/item JSON + loot ----
    tex_dir = os.path.join(ASSETS, "textures/block")
    os.makedirs(tex_dir, exist_ok=True)
    for old in os.listdir(tex_dir):  # remove textures of earlier generator versions
        os.remove(os.path.join(tex_dir, old))
    for fid, color, _, _ in FACTIONS:
        make_palette(color).save(os.path.join(tex_dir, f"pal_{fid}.png"))
    make_side_texture(0x8A8F98).save(os.path.join(tex_dir, "side_neutral.png"))

    def write_state_and_loot(bid, rotated=False):
        # 16 steps of 22.5 deg (like a standing sign). Blockstate y only allows multiples of 90, so the
        # remaining 0 / +22.5 / +45 / -22.5 offsets come from pre-rotated model variants <bid>_r1/_r2/_r3.
        variants = {}
        for r in range(16):
            k, rem = divmod(r, 4)
            suffix = ""
            if rem == 3:
                k, suffix = (k + 1) % 4, "_r3"
            elif rem == 1:
                suffix = "_r1"
            elif rem == 2:
                suffix = "_r2"
            if not rotated:  # flat markers: snap to 90 degrees
                k, suffix = round(r / 4) % 4, ""
            v = {"model": f"{MODID}:block/{bid}{suffix}"}
            if k:
                v["y"] = 90 * k
            variants[f"rotation={r}"] = v
        save_json(os.path.join(ASSETS, "blockstates", f"{bid}.json"), {"variants": variants})
        save_json(os.path.join(DATA, "loot_tables/blocks", f"{bid}.json"), {
            "type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": f"{MODID}:{bid}"}],
                                                  "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

    def emit_unit(uid, fid, cls, name, signature):
        heavy = bool(name) and ("Heavy" in name or "Command" in name or "Grand" in name)
        parts = models3d.build(cls, heavy, signature)
        models3d.clamp_check(parts)
        pal = f"{MODID}:block/pal_{fid}"
        # model element rotation: positive = counter-clockwise seen from above, blockstate y = clockwise,
        # so a clockwise offset d is written as angle -d.
        for suffix, d in (("", 0), ("_r1", 22.5), ("_r2", 45), ("_r3", -22.5)):
            elements = []
            for (x1, y1, z1, x2, y2, z2, slot) in parts:
                cx, cy = (slot % 4) * 4, (slot // 4) * 4
                uv = [cx + 1, cy + 1, cx + 3, cy + 3]
                faces = {dd: {"texture": "#p", "uv": uv} for dd in ("north", "south", "east", "west", "up", "down")}
                el = {"from": [x1, y1, z1], "to": [x2, y2, z2], "faces": faces}
                if d:
                    el["rotation"] = {"origin": [8, 0, 8], "axis": "y", "angle": -d}
                elements.append(el)
            save_json(os.path.join(ASSETS, "models/block", f"{uid}{suffix}.json"),
                      {"parent": "minecraft:block/block", "textures": {"p": pal, "particle": pal}, "elements": elements})
        save_json(os.path.join(ASSETS, "models/item", f"{uid}.json"), {"parent": f"{MODID}:block/{uid}"})
        write_state_and_loot(uid, rotated=True)

    def emit_block(bid, side, texture_img):
        texture_img.save(os.path.join(ASSETS, "textures/block", f"{bid}.png"))
        face = lambda t, uv=None: ({"texture": t, "uv": uv} if uv else {"texture": t})
        model = {
            "textures": {"top": f"{MODID}:block/{bid}", "side": f"{MODID}:block/side_{side}",
                         "particle": f"{MODID}:block/side_{side}"},
            "elements": [{"from": [1, 0, 1], "to": [15, 2, 15], "faces": {
                "up": face("#top", [1, 1, 15, 15]), "down": face("#side"),
                "north": face("#side"), "south": face("#side"), "east": face("#side"), "west": face("#side")}}],
        }
        save_json(os.path.join(ASSETS, "models/block", f"{bid}.json"), model)
        save_json(os.path.join(ASSETS, "models/item", f"{bid}.json"),
                  {"parent": "item/generated", "textures": {"layer0": f"{MODID}:block/{bid}"}})
        write_state_and_loot(bid)

    for uid, fid, cls, name, sig in units:
        emit_unit(uid, fid, cls, name, sig)
        cen, cru = CLASSES[cls][0], CLASSES[cls][1]
        if sig:
            lang_en[f"block.{MODID}.{uid}"] = name
            lang_ru[f"block.{MODID}.{uid}"] = name
        else:
            lang_en[f"block.{MODID}.{uid}"] = f"{fen[fid]} {cen} Token"
            lang_ru[f"block.{MODID}.{uid}"] = f"Жетон: {cru.split(' — ')[0]} ({fru[fid]})"

    for uid, (en_i, ru_i) in INFO.items():
        lang_en[f"unitinfo.{MODID}.{uid}"] = en_i
        lang_ru[f"unitinfo.{MODID}.{uid}"] = ru_i
    for mid, color, gk, en, ru in MARKERS:
        emit_block(mid, "neutral", make_token_texture(color, gk, False))
        lang_en[f"block.{MODID}.{mid}"] = en
        lang_ru[f"block.{MODID}.{mid}"] = ru

    for name, img in make_tool_textures().items():
        os.makedirs(os.path.join(ASSETS, "textures/item"), exist_ok=True)
        img.save(os.path.join(ASSETS, "textures/item", f"{name}.png"))
        save_json(os.path.join(ASSETS, "models/item", f"{name}.json"),
                  {"parent": "item/generated", "textures": {"layer0": f"{MODID}:item/{name}"}})

    # ---- lang ----
    for fid, _c, en, ru in FACTIONS:
        lang_en[f"itemGroup.{MODID}.{fid}"] = f"Dystopian Wars: {en}"
        lang_ru[f"itemGroup.{MODID}.{fid}"] = f"Dystopian Wars: {ru}"
        lang_en[f"faction.{MODID}.{fid}"] = en
        lang_ru[f"faction.{MODID}.{fid}"] = ru
    lang_en[f"itemGroup.{MODID}.rules"] = "Dystopian Wars: Rules & Tools"
    lang_ru[f"itemGroup.{MODID}.rules"] = "Dystopian Wars: Правила и инструменты"
    lang_en[f"faction.{MODID}.neutral"] = "Neutral"
    lang_ru[f"faction.{MODID}.neutral"] = "Нейтральный"
    for k, (en, ru) in CLASSES.items():
        lang_en[f"class.{MODID}.{k}"] = en
        lang_ru[f"class.{MODID}.{k}"] = ru
    L = lambda k, en, ru: (lang_en.__setitem__(k, en), lang_ru.__setitem__(k, ru))
    L(f"tooltip.{MODID}.stats", "Stats: see the official Warcradle ORBAT", "Характеристики — в официальном ORBAT Warcradle")
    L(f"tooltip.{MODID}.place", "Place it on a flat surface; it faces the way you look", "Ставится на ровную поверхность носом туда, куда вы смотрите")
    L(f"item.{MODID}.action_dice", "Action Dice", "Кубики действий (Action Dice)")
    L(f"item.{MODID}.critical_die", "Critical Damage Die", "Кубик критического урона")
    L(f"item.{MODID}.ruler", "Admiral's Ruler (1 block = 1\")", "Линейка адмирала (1 блок = 1 дюйм)")
    L(f"tooltip.{MODID}.action_dice.1", "Right-click: roll as many dice as are in the stack", "ПКМ: бросить столько кубиков, сколько в стопке")
    L(f"tooltip.{MODID}.action_dice.2", "Exploding Strikes add more dice automatically", "Exploding Strike автоматически добавляет кубики")
    L(f"tooltip.{MODID}.critical_die.1", "Right-click: roll one Critical Damage Die", "ПКМ: бросить кубик критического урона")
    L(f"tooltip.{MODID}.ruler.1", "Click a block to set point A, then click others to measure", "Клик по блоку — точка A, следующие клики — замер")
    L(f"tooltip.{MODID}.ruler.2", "Sneak + click: set a new point A. Sneak + right-click air: reset", "Shift + клик: новая точка A. Shift + ПКМ в воздух: сброс")
    L(f"tooltip.{MODID}.ruler.3", "Vertical distance is ignored, as in the rules", "Высота игнорируется, как в правилах")
    faces = [("blank", "Blank", "Пусто (Blank)"),
             ("std_counter", "Standard Counter (-1 Hit)", "Standard Counter (−1 попадание)"),
             ("heavy_counter", "Heavy Counter (-2 Hits)", "Heavy Counter (−2 попадания)"),
             ("std_strike", "Standard Strike (1 Hit)", "Standard Strike (1 попадание)"),
             ("heavy_strike", "Heavy Strike (2 Hits)", "Heavy Strike (2 попадания)"),
             ("exploding", "Exploding Strike (2 Hits + extra die)", "Exploding Strike (2 попадания + доп. кубик)")]
    for k, en, ru in faces:
        L(f"face.{MODID}.{k}", en, ru)
    crits = [("breach", "Breach: 1 Damage per token in Consolidation", "Breach: 1 урон за жетон на шаге Consolidation"),
             ("structural", "Structural Failure: -1 Armour per token", "Structural Failure: −1 Armour за жетон"),
             ("hazard", "Hazard: 1 Disorder per token in Consolidation, cannot Rally", "Hazard: 1 Disorder за жетон на Consolidation, Rally невозможен"),
             ("shredded", "Shredded Defences: -2 Defences per token", "Shredded Defences: −2 Defences за жетон"),
             ("navlock", "Navigation Lock: cannot Come About or Full Reverse", "Navigation Lock: нельзя Come About и Full Reverse"),
             ("sysfail", "System Failure: all Systems negated", "System Failure: все Systems отключены")]
    for k, en, ru in crits:
        L(f"crit.{MODID}.{k}", en, ru)
    L(f"msg.{MODID}.dice.header", "%s rolls %s Action Dice:", "%s бросает кубиков действий: %s")
    L(f"msg.{MODID}.dice.total", "Hits: %s | Counters: %s | Extra dice from Exploding: %s",
      "Попаданий: %s | Контр-символов: %s | Доп. кубиков от Exploding: %s")
    L(f"msg.{MODID}.crit.header", "%s rolls a Critical Damage Die: ", "%s бросает кубик критического урона: ")
    L(f"msg.{MODID}.ruler.set", "Point A set at (%s, %s). Click another block to measure.", "Точка A: (%s, %s). Кликните по другому блоку для замера.")
    L(f"msg.{MODID}.ruler.result", "Distance: %s\" — %s", "Расстояние: %s\" — %s")
    L(f"msg.{MODID}.ruler.reset", "Ruler reset", "Линейка сброшена")
    L(f"band.{MODID}.close", "Close range (up to 10\")", "Close — ближняя дистанция (до 10\")")
    L(f"band.{MODID}.standard", "Standard range (10\"-30\")", "Standard — средняя дистанция (10\"–30\")")
    L(f"band.{MODID}.extreme", "Extreme range (over 30\")", "Extreme — дальняя дистанция (больше 30\")")
    L(f"band.{MODID}.edge10", "Exactly 10\": the active Admiral chooses Close or Standard", "Ровно 10\": активный адмирал выбирает Close или Standard")
    L(f"band.{MODID}.edge30", "Exactly 30\": the active Admiral chooses Standard or Extreme", "Ровно 30\": активный адмирал выбирает Standard или Extreme")
    L(f"msg.{MODID}.table.done", "Play area %s x %s built (1 block = 1 inch). Lines every 10 blocks.",
      "Игровое поле %s × %s построено (1 блок = 1 дюйм). Линии через каждые 10 блоков.")
    save_json(os.path.join(ASSETS, "lang/en_us.json"), lang_en)
    save_json(os.path.join(ASSETS, "lang/ru_ru.json"), lang_ru)

    # ---- UnitData.java ----
    lines = ["package dev.dwmod;", "", "import java.util.List;", "",
             "/** GENERATED by tools/generate_assets.py - do not edit by hand. */",
             "public final class UnitData {",
             "    private UnitData() {}", "",
             "    public record Faction(String id, int color) {}",
             "    public record Unit(String id, String faction, String unitClass, boolean signature) {}", "",
             "    public static final List<Faction> FACTIONS = List.of("]
    lines.append(",\n".join(f'        new Faction("{f[0]}", 0x{f[1]:06X})' for f in FACTIONS))
    lines.append("    );\n")
    lines.append("    public static final List<Unit> UNITS = List.of(")
    lines.append(",\n".join(f'        new Unit("{u[0]}", "{u[1]}", "{u[2]}", {"true" if u[4] else "false"})' for u in units))
    lines.append("    );\n")
    lines.append("    public static final java.util.Map<String, List<String>> BOOKS = java.util.Map.of(")
    lines.append(",\n".join('        "%s", List.of(%s)' % (k, ", ".join('"%s"' % b for b in v)) for k, v in BOOKS.items()))
    lines.append("    );\n")
    lines.append("    public static final List<String> MARKERS = List.of(")
    lines.append(",\n".join(f'        "{m[0]}"' for m in MARKERS))
    lines.append("    );")
    lines.append("}")
    write(JAVA, "\n".join(lines) + "\n")
    print(f"units: {len(units)}, markers: {len(MARKERS)}")


if __name__ == "__main__":
    main()
