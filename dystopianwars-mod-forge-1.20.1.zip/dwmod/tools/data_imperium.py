import os
KEYS = "MAS SPD TRN DEF ARM HUL ACT BRD REP CRW".split()
UNITS = []
for _l in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "data_imperium_raw.txt"), encoding="utf-8"):
    if not _l.strip() or _l.startswith("#"):
        continue
    n, cat, cls, pts, models, st, props, systems, weapons, opts = _l.rstrip("\n").split("|")
    ws = []
    if weapons.strip() not in ("", "-"):
        for w in weapons.split(";;"):
            wn, arc, cse, q = [x.strip() for x in w.split("@")]
            ws.append((wn, arc, cse, q))
    UNITS.append(dict(name=n, cat=cat, cls=cls, pts=int(pts), models=models, stats=dict(zip(KEYS, st.split("/"))),
                      props=props, systems=systems, weapons=ws, opts=opts))
CATS = ["Flagship", "Line", "Patrol", "Support", "Scout", "Logistical"]
R = [(c, [(u["name"], u["cls"]) for u in UNITS if u["cat"] == c]) for c in CATS]
SRS = [("Blitzen Bombers","srs"),("Messer Interceptors","srs"),("Vali Midget Subs","srs"),("Landing Party","escort"),("Escort","escort")]
WEAPONS = ["Rüdiger Heavy Voltaic Gun Battery","Autokanone Stromschlag Rocket Battery","Light Voltaic Gun Battery",
 "Erderschütterer Rocket Battery","Sturmklaue Vierling Autokanone","Sturmbringer Vierling Flak Array",
 "Heavy Sturmklaue Luft Speerschleuders","Bertha Heavy Bombard","Gustav Twin Bombard","Uber Volt Vierling"]
